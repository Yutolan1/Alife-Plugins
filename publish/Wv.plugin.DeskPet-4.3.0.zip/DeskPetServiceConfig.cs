namespace Wv.plugin.DeskPet;

public record DeskPetServiceConfig
{
    public int BubbleDurationPerCharMs { get; set; } = 150;
}