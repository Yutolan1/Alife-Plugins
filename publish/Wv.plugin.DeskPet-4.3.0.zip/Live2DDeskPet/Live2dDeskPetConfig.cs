namespace Wv.plugin.DeskPet;

public record Live2DDeskPetConfig
{
    public string ModelName { get; set; } = "Mao";
}