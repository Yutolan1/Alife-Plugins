using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using Alife.Foundation;

namespace Wv.plugin.DeskPet;

#region Live2D官方规范扩展

public record ExpressionItem(string? Name);

public record MotionItem(string? Name, string? File);

public record FileReferencesModel
{
    public List<ExpressionItem> Expressions { get; set; } = new();
    public Dictionary<string, List<MotionItem>> Motions { get; set; } = new();
}

#endregion

#region 自定义的交互反馈

public record MotionRef(string Group, int Index);

public record InteractionItem(string? Text, string? Exp, MotionRef? Mtn);

#endregion

/// <summary>
/// Live2D 模型元数据载体与解析器
/// </summary>
public class PetModelMetadata
{
    public string ModelPath { get; private set; } = string.Empty;
    public List<string> Expressions { get; private set; } = new();
    public Dictionary<string, (string Group, int Index)> Motions { get; private set; } = new();
    public Dictionary<string, List<InteractionItem>> Interactions { get; private set; } = new();

    /// <summary>每个动作的自循环与时长（读自动作文件 Meta）：循环的天然"保持"，一次性动作靠按时长重发来保持。</summary>
    public Dictionary<string, (bool Loop, double Duration)> MotionMeta { get; private set; } = new();

    /// <summary>
    /// 就地替换为另一份元数据。模型切换时用：各模块持有的是同一个 metadata 实例，
    /// 直接换掉内部集合的引用即可让它们看到新模型——整体换引用是原子的，
    /// 不会出现「Clear 之后、Add 之前」被别的线程读到空集合的情况（那样会 First() 抛异常）。
    /// </summary>
    public void ReplaceWith(PetModelMetadata other)
    {
        ModelPath = other.ModelPath;
        Expressions = other.Expressions;
        Motions = other.Motions;
        Interactions = other.Interactions;
        MotionMeta = other.MotionMeta;
    }

    /// <summary>整体替换交互池（编辑保存时用，同样是原子换引用）。</summary>
    public void SetInteractions(Dictionary<string, List<InteractionItem>> map) => Interactions = map;

    /// <summary>从模型目录加载元数据（目录内按规范解析模型描述文件）。</summary>
    public static PetModelMetadata Load(string modelDirectory)
    {
        PetModelMetadata metadata = new();

        //按 Live2D 目录规范解析模型描述文件：目录名即模型名，定位 {目录名}.model3.json，缺省回退 .model.json。
        string modelJsonPath = ResolveModelJsonPath(modelDirectory);
        string ResolveModelJsonPath(string modelDirectory)
        {
            string modelName = Path.GetFileName(modelDirectory);
            string model3JsonPath = Path.Combine(modelDirectory, $"{modelName}.model3.json");
            if (File.Exists(model3JsonPath)) return model3JsonPath;

            string modelJsonPath = Path.Combine(modelDirectory, $"{modelName}.model.json");
            if (File.Exists(modelJsonPath)) return modelJsonPath;

            return model3JsonPath;
        }
        if (File.Exists(modelJsonPath) == false)
            return metadata;

        // 设置模型绝对路径，用于 Web 端通过 file:// 加载
        metadata.ModelPath = modelJsonPath.Replace('\\', '/');

        try
        {
            JsonSerializerOptions options = new() { PropertyNameCaseInsensitive = true };
            using JsonDocument jsonDoc = JsonDocument.Parse(File.ReadAllText(modelJsonPath));
            JsonElement root = jsonDoc.RootElement;

            //收集支持的表情动作
            {
                JsonElement refs = root.TryGetProperty("FileReferences", out JsonElement fileRefs) ? fileRefs : root;
                FileReferencesModel model = JsonSerializer.Deserialize<FileReferencesModel>(refs.GetRawText(), options) ?? new();

                foreach (ExpressionItem exp in model.Expressions)
                {
                    if (string.IsNullOrEmpty(exp.Name) == false)
                        metadata.Expressions.Add(exp.Name);
                }

                foreach ((string groupName, List<MotionItem> items) in model.Motions)
                {
                    for (int index = 0; index < items.Count; index++)
                    {
                        MotionItem item = items[index];
                        string name = string.IsNullOrEmpty(item.Name)
                            ? Path.GetFileNameWithoutExtension(item.File ?? "") //动作 Name 并不是官方规范，所以备用拿 File 名称
                            : item.Name;
                        if (string.IsNullOrEmpty(name) == false)
                        {
                            metadata.Motions[name] = (groupName, index);
                            metadata.MotionMeta[name] = ReadMotionMeta(modelDirectory, item.File);
                        }
                    }
                }
            }

            // 交互配置
            if (root.TryGetProperty("Interaction", out JsonElement interactJson))
            {
                foreach (JsonProperty poolProp in interactJson.EnumerateObject())
                {
                    metadata.Interactions[poolProp.Name] =
                        JsonSerializer.Deserialize<List<InteractionItem>>(poolProp.Value.GetRawText(), options) ?? new();
                }
            }
        }
        catch (Exception e)
        {
            AlifeLog.LogError("Live2D模型解析失败\n" + e);
        }

        return metadata;
    }

    /// <summary>读动作文件的 Meta（是否自循环 / 总时长），供"保持动作"用。</summary>
    static (bool Loop, double Duration) ReadMotionMeta(string modelDirectory, string? file)
    {
        try
        {
            if (string.IsNullOrEmpty(file)) return (false, 0);
            string path = Path.Combine(modelDirectory, file.Replace('/', Path.DirectorySeparatorChar));
            if (File.Exists(path) == false) return (false, 0);
            using JsonDocument doc = JsonDocument.Parse(File.ReadAllText(path));
            if (doc.RootElement.TryGetProperty("Meta", out JsonElement meta) == false) return (false, 0);
            bool loop = meta.TryGetProperty("Loop", out JsonElement loopProp) && loopProp.ValueKind == JsonValueKind.True;
            double duration = meta.TryGetProperty("Duration", out JsonElement durProp) && durProp.ValueKind == JsonValueKind.Number
                ? durProp.GetDouble() : 0;
            return (loop, duration);
        }
        catch { return (false, 0); }
    }
}