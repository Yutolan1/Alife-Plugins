// ---- Electron 通讯 ----

// 每个桌宠实例使用独立的 IPC 频道，避免多开时消息互相串扰
var petChannel = new URLSearchParams(location.search).get('petChannel') || 'pet';

function getIpc() {
    var electron = require('electron');
    return electron.ipcRenderer;
}

function postMessage(data) {
    try {
        getIpc().send(petChannel, JSON.stringify(data));
    } catch {
    }
}

const messageBus = {
    _handlers: new Map(),
    on(type, handler) {
        if (!this._handlers.has(type)) {
            this._handlers.set(type, []);
        }

        this._handlers.get(type).push(handler);
    },
    _dispatch(msg) {
        const handlers = this._handlers.get(msg.type) || [];

        handlers.forEach(handler => handler(msg));
    }
};

getIpc().on(petChannel, function (event, msg) {
    if (typeof msg === 'string') {
        try {
            msg = JSON.parse(msg);
        } catch {
            return;
        }
    }
    messageBus._dispatch(msg);
});


// ---- 前端日志转发 ----
function formatLogArg(arg) {
    if (arg instanceof Error) return arg.name + ': ' + arg.message + '\n' + (arg.stack || '');
    if (typeof arg === 'object') {
        try {
            return JSON.stringify(arg);
        } catch {
            return String(arg);
        }
    }
    return String(arg);
}

function postLog(level) {
    try {
        var args = Array.prototype.slice.call(arguments, 1);
        postMessage({
            type: 'log',
            level: level,
            text: args.map(formatLogArg).join(' ')
        });
    } catch {
    }
}

{
    var rawWarn = console.warn.bind(console);
    var rawError = console.error.bind(console);
    console.warn = function () {
        postLog.apply(null, ['warn'].concat(Array.prototype.slice.call(arguments)));
        rawWarn.apply(console, arguments);
    };
    console.error = function () {
        postLog.apply(null, ['error'].concat(Array.prototype.slice.call(arguments)));
        rawError.apply(console, arguments);
    };
}

window.addEventListener('error', function (e) {
    var target = e.target;
    if (target && target !== window) {
        postLog('resource-error', target.tagName || 'unknown', target.src || target.href || '');
        return;
    }
    postLog('error', e.message, e.filename + ':' + e.lineno + ':' + e.colno, e.error || '');
}, true);

window.addEventListener('unhandledrejection', function (e) {
    postLog('unhandledrejection', e.reason);
});

// ---- 前端资源注入辅助 ----
function injectCSS(css) {
    var style = document.createElement('style');
    style.textContent = css;
    document.head.appendChild(style);
}

function injectHTML(html) {
    var div = document.createElement('div');
    div.innerHTML = html;
    while (div.firstChild) document.body.appendChild(div.firstChild);
}

// ---- 加载模型 ----

messageBus.on('load', function (msg) {
    loadModel(msg.url);
});

const app = new PIXI.Application({
    view: document.getElementById('canvas'),
    autoStart: true,
    resizeTo: window,
    transparent: true,
    backgroundAlpha: 0,
    preserveDrawingBuffer: true, // 保留帧缓冲，允许读取像素（生成人形掩码）
});

let model = null;

// 用户在模型上的追加偏移与缩放（独立于布局基准，窗口 resize/updateLayout 不会重置）
let userScale = 1;
let userOffsetX = 0;
let userOffsetY = 0;

// 当前模型视图（窗口 CSS 像素）：mx/my=模型中心位置，ms=每模型单位的像素数。
// 点击区域/穿透判定/配置面板靠它做「模型单位 ⇄ 窗口坐标」换算，与对话框 --ui-scale 同源。
var petView = { mx: 0, my: 0, ms: 1, dirty: false, sentMx: NaN, sentMy: NaN, sentMs: NaN };

// 视图变化时同步：置脏（节流上报主进程）+ 通知 overlay 图层贴模型（region 模块注入后生效）
function updatePetView() {
    if (!model) return;
    petView.mx = model.position.x;
    petView.my = model.position.y;
    petView.ms = model.scale.x || 1;
    petView.dirty = true;
    // 模型中心水平位置暴露给 CSS（气泡等 UI 用它贴住模型，而不是锚死窗口中心）
    document.documentElement.style.setProperty('--model-cx', petView.mx + 'px');
    if (typeof window.onPetViewChanged === 'function') window.onPetViewChanged();
}

// pet_view 节流上报：100ms 合并一次且值没变不发——拖动/缩放期间最多 10 条/秒，
// 避免高频 IPC 轰炸主进程（此前主进程在 pet_view 路径做重活导致整个 Alife 卡死）。
setInterval(function () {
    if (!petView.dirty) return;
    petView.dirty = false;
    if (petView.mx === petView.sentMx && petView.my === petView.sentMy && petView.ms === petView.sentMs) return;
    petView.sentMx = petView.mx; petView.sentMy = petView.my; petView.sentMs = petView.ms;
    postMessage({ type: 'pet_view', mx: petView.mx, my: petView.my, ms: petView.ms });
}, 100);

// 模块加载完成后调用：作废去重标记，强制下个周期重发一次当前视图
//（主进程模块订阅可能晚于最早一次上报，静息状态下没有这条就永远拿不到视图）
window.requestPetView = function () {
    petView.dirty = true;
    petView.sentMx = NaN; petView.sentMy = NaN; petView.sentMs = NaN;
};

// 模型缩放策略（原始设计）：模型高度 = 窗口高度的 110%，水平垂直居中。
// 窗口是主人：窗口一 resize（用户拉伸/代码调整），模型跟着缩放，模型高 = 窗口高 × 1.1。
function applyTransform() {
    if (!model) return;
    var bh = model.internalModel.originalHeight; // 画布逻辑高
    var sc = (window.innerHeight * 1.1) / bh;    // 模型高 = 窗口高 × 1.1
    model.scale.set(sc * userScale);
    model.position.set(window.innerWidth * 0.5 + userOffsetX, window.innerHeight * 0.5 + userOffsetY);
    updatePetView();
}

async function loadModel(url) {
    console.log('[Pet] Loading model:', url);
    if (model) app.stage.removeChild(model);
    try {
        model = await PIXI.live2d.Live2DModel.from(url, {autoInteract: false});
        console.log('[Pet] Model loaded successfully');
    } catch (err) {
        console.error('[Pet] Live2D model load failed:', err);
        postMessage({type: 'loaded'});
        return;
    }
    app.stage.addChild(model);
    
    var updateLayout = function () {
        var s = window.innerHeight / 540;
        document.documentElement.style.setProperty('--ui-scale', s);
        applyTransform();
    };

    model.anchor.set(0.5, 0.5);
    updateLayout();
    model.interactive = true;
    window.addEventListener('resize', updateLayout);

    // 上报模型原始尺寸（逻辑单位），供主进程自动贴合窗口：宽 = 当前高 × 宽高比
    postMessage({
        type: 'model_info',
        ow: model.internalModel.originalWidth,
        oh: model.internalModel.originalHeight
    });
    postMessage({type: 'loaded'});
}

// ---- 初始化完成 ----
postMessage({type: 'init'});
