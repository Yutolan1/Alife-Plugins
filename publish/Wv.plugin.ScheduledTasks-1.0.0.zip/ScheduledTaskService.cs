using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Alife.Foundation;
using Alife.Framework;
using Alife.Function.FunctionCaller;

namespace Alife.Function.ScheduledTasks;

/// <summary>定时任务配置，随角色配置持久化。</summary>
public class ScheduledTaskConfig
{
    public List<ScheduledTask> ScheduledTasks { get; set; } = new();
}

/// <summary>一个定时任务。Type 可选：daily(每天)/weekly(每周)/monthly(每月)/yearly(每年)/once(一次性)。</summary>
public class ScheduledTask
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string Type { get; set; } = "daily";
    public int? WeekDay { get; set; }    // weekly: 0=周日..6=周六
    public int? DayOfMonth { get; set; } // monthly/yearly: 1-31
    public int? Month { get; set; }      // yearly: 1-12
    public int Hour { get; set; }        // 0-23
    public int Minute { get; set; }      // 0-59
    public DateTime? ExactTime { get; set; } // once: 精确触发时间
    public string Remark { get; set; } = "";
    public DateTime LastTriggered { get; set; } = DateTime.MinValue; // 上次触发时间，用于防止重复触发
}

[Module("定时任务",
    "创建每日/每周/每月/每年/一次性的定时任务，到点后系统主动提醒AI。",
    defaultCategory: "Wv的工具",
    LaunchOrder = 100)]
public class ScheduledTaskService(
    XmlFunctionCaller functionService,
    Interactor<ScheduledTaskService> interactor) :
    ChatBehaviour,
    IConfigurable<ScheduledTaskConfig>
{
    public ScheduledTaskConfig Configuration { get; set; } = null!;

    string? tasksFilePath; // 定时任务持久化文件路径（按角色存储，重启不丢失）
    static readonly JsonSerializerOptions TasksJsonOpts = new() {
        WriteIndented = true,
        Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping
    };

    protected override Task OnAwake()
    {
        // 定时任务按角色持久化到配置目录，重启后恢复
        tasksFilePath = Path.Combine(AlifePath.StorageFolderPath, Character.StorageKey, "Configuration", "ScheduledTasks.json");
        LoadScheduledTasks();

        XmlHandler xmlHandler = new(this) {
            Description = "创建每日/每周/每月/每年/一次性的定时任务，到点后系统主动提醒AI。",
            Explanation = """
                          定时任务会持久化保存，即使程序重启也不会丢失，可以放心长期安排日程。
                          例如偷偷记下主人的日常起居时间，来个早晚问候，或白天主动找用户聊天。
                          可以结合主动事件插件一起使用，让自己保持活跃。
                          """
        };
        functionService.RegisterHandler(xmlHandler, cancellationToken: DestroyCancellationToken);

        return Task.CompletedTask;
    }

    protected override Task OnUpdate()
    {
        // 对齐帧率，避免每帧都检查
        if (UpdateContext.FrameCount % (int)(1 / UpdateContext.ExpectedDeltaTime) != 0)
            return Task.CompletedTask;

        CheckScheduledTasks();
        return Task.CompletedTask;
    }

    protected override Task OnDestroy()
    {
        SaveScheduledTasks(); // 确保触发状态落盘
        return Task.CompletedTask;
    }

    [XmlFunction(FunctionMode.OneShot)]
    [Description("创建一个定时任务，支持每天/每周/每月/每年/一次性五种类型，到点后系统会主动提醒你")]
    public void ScheduleTask(
        [Description("任务类型：daily=每天, weekly=每周, monthly=每月, yearly=每年, once=一次性")] string type,
        [Description("小时(0-23)，daily/weekly/monthly/yearly必填")] int hour = 0,
        [Description("分钟(0-59)，daily/weekly/monthly/yearly必填")] int minute = 0,
        [Description("仅weekly：星期几，0=周日,1=周一...6=周六")] int? weekday = null,
        [Description("仅monthly/yearly：几号(1-31)，超过当月天数的日期将顺延到月末触发")] int? dayOfMonth = null,
        [Description("仅yearly：月份(1-12)")] int? month = null,
        [Description("仅once：精确触发时间，ISO-8601格式，如2025-12-31T08:30:00，必须是未来时间；未设置时使用default")] DateTime time = default,
        [Description("任务备注，触发提醒时使用，例如\"提醒主人吃药\"")] string remark = "")
    {
        type = (type ?? "").Trim().ToLowerInvariant();

        if (type is not ("daily" or "weekly" or "monthly" or "yearly" or "once"))
        {
            interactor.Poke($"不支持的定时任务类型\"{type}\"，可选：daily(每天)/weekly(每周)/monthly(每月)/yearly(每年)/once(一次性)");
            return;
        }
        if (hour is < 0 or > 23)
        {
            interactor.Poke("hour 必须在 0-23 之间");
            return;
        }
        if (minute is < 0 or > 59)
        {
            interactor.Poke("minute 必须在 0-59 之间");
            return;
        }
        if (type == "weekly" && weekday is not (>= 0 and <= 6))
        {
            interactor.Poke("weekly 任务需要 weekday 在 0(周日)-6(周六) 之间");
            return;
        }
        if (type is "monthly" or "yearly" && (dayOfMonth is null or < 1 or > 31))
        {
            interactor.Poke($"{type} 任务需要 dayOfMonth 在 1-31 之间");
            return;
        }
        if (type == "yearly" && month is null or < 1 or > 12)
        {
            interactor.Poke("yearly 任务需要 month 在 1-12 之间");
            return;
        }
        if (type == "once" && (time == default || time <= DateTime.Now))
        {
            interactor.Poke("once 任务需要提供未来的 time（ISO-8601格式，如2025-12-31T08:30:00）");
            return;
        }

        ScheduledTask task = new() {
            Type = type,
            Hour = type == "once" ? time.Hour : hour,
            Minute = type == "once" ? time.Minute : minute,
            WeekDay = weekday,
            DayOfMonth = dayOfMonth,
            Month = month,
            ExactTime = type == "once" ? time : null,
            Remark = remark
        };
        Configuration.ScheduledTasks.Add(task);

        interactor.Poke($"已创建定时任务，ID={task.Id}，{DescribeTask(task)}，备注：{remark}");
        SaveScheduledTasks();
    }

    [XmlFunction(FunctionMode.OneShot)]
    [Description("删除一个已创建的定时任务，参数为任务ID或备注")]
    public void RemoveScheduledTask(string id)
    {
        if (Configuration.ScheduledTasks.Count == 0)
        {
            interactor.Poke("当前没有任何定时任务");
            return;
        }

        id = (id ?? "").Trim();
        ScheduledTask? task = Configuration.ScheduledTasks.FirstOrDefault(t => t.Id == id || t.Remark == id);
        if (task == null)
        {
            interactor.Poke($"未找到ID或备注为\"{id}\"的定时任务，可使用<{nameof(ListScheduledTasks)}>查看全部任务");
            return;
        }
        Configuration.ScheduledTasks.Remove(task);
        interactor.Poke($"已删除定时任务：{DescribeTask(task)}（备注：{task.Remark}）");
        SaveScheduledTasks();
    }

    [XmlFunction(FunctionMode.OneShot)]
    [Description("列出所有已创建的定时任务及其下一次触发时间")]
    public void ListScheduledTasks()
    {
        if (Configuration.ScheduledTasks.Count == 0)
        {
            interactor.Poke("当前没有任何定时任务");
            return;
        }

        StringBuilder builder = new();
        builder.AppendLine("当前定时任务：");
        foreach (ScheduledTask task in Configuration.ScheduledTasks)
        {
            DateTime next = GetNextTriggerTime(task, DateTime.Now);
            builder.AppendLine($"- ID={task.Id} | {DescribeTask(task)} | 下次触发: {next:yyyy-MM-dd HH:mm:ss} | 备注: {task.Remark}");
        }
        interactor.Poke(builder.ToString().TrimEnd());
    }

    void CheckScheduledTasks()
    {
        if (Configuration.ScheduledTasks.Count == 0)
            return;

        DateTime now = DateTime.Now;
        bool changed = false;
        List<ScheduledTask>? finishedOnce = null;

        foreach (ScheduledTask task in Configuration.ScheduledTasks)
        {
            DateTime lastDue = GetLastDueTime(task, now);
            if (lastDue == DateTime.MaxValue || lastDue > now || task.LastTriggered >= lastDue)
                continue; // 未到点，或本周期已触发过

            task.LastTriggered = lastDue;
            changed = true;
            interactor.Poke($"定时任务触发：{task.Remark}（{DescribeTask(task)}）");

            if (task.Type == "once")
                (finishedOnce ??= new()).Add(task); // 一次性任务触发后移除
        }

        if (finishedOnce != null)
        {
            foreach (ScheduledTask task in finishedOnce)
                Configuration.ScheduledTasks.Remove(task);
            changed = true;
        }

        if (changed)
            SaveScheduledTasks(); // 持久化触发状态与一次性任务的移除
    }

    /// <summary>返回 now 之前（含）最近的应触发时间点；若 now 之前没有触发点则返回未来时间或 MaxValue。</summary>
    static DateTime GetLastDueTime(ScheduledTask task, DateTime now)
    {
        switch (task.Type)
        {
            case "daily":
            {
                DateTime candidate = now.Date.AddHours(task.Hour).AddMinutes(task.Minute);
                return candidate <= now ? candidate : candidate.AddDays(-1);
            }
            case "weekly":
            {
                int target = (task.WeekDay ?? (int)now.DayOfWeek) % 7;
                int diff = (target - (int)now.DayOfWeek + 7) % 7;
                DateTime candidate = now.Date.AddHours(task.Hour).AddMinutes(task.Minute).AddDays(diff);
                return candidate <= now ? candidate : candidate.AddDays(-7);
            }
            case "monthly":
            {
                int day = Math.Clamp(task.DayOfMonth ?? now.Day, 1, 31);
                DateTime candidate = BuildMonthly(now.Year, now.Month, day, task.Hour, task.Minute);
                if (candidate <= now)
                    return candidate;
                DateTime prev = now.AddMonths(-1);
                return BuildMonthly(prev.Year, prev.Month, day, task.Hour, task.Minute);
            }
            case "yearly":
            {
                int month = Math.Clamp(task.Month ?? now.Month, 1, 12);
                int day = Math.Clamp(task.DayOfMonth ?? now.Day, 1, 31);
                DateTime candidate = BuildMonthly(now.Year, month, day, task.Hour, task.Minute);
                if (candidate <= now)
                    return candidate;
                return BuildMonthly(now.Year - 1, month, day, task.Hour, task.Minute);
            }
            case "once":
                return task.ExactTime ?? DateTime.MaxValue;
            default:
                return DateTime.MaxValue;
        }
    }

    void LoadScheduledTasks()
    {
        if (tasksFilePath == null || File.Exists(tasksFilePath) == false)
            return;

        try
        {
            List<ScheduledTask>? list = JsonSerializer.Deserialize<List<ScheduledTask>>(File.ReadAllText(tasksFilePath), TasksJsonOpts);
            if (list == null)
                return;
            Configuration ??= new ScheduledTaskConfig();
            Configuration.ScheduledTasks = list;
        }
        catch (Exception e)
        {
            Console.WriteLine($"[定时任务] 加载定时任务失败：{e.Message}");
        }
    }

    void SaveScheduledTasks()
    {
        if (tasksFilePath == null)
            return;

        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(tasksFilePath)!);
            File.WriteAllText(tasksFilePath, JsonSerializer.Serialize(Configuration.ScheduledTasks, TasksJsonOpts));
        }
        catch (Exception e)
        {
            Console.WriteLine($"[定时任务] 保存定时任务失败：{e.Message}");
        }
    }

    static DateTime GetNextTriggerTime(ScheduledTask task, DateTime from)
    {
        switch (task.Type)
        {
            case "daily":
            {
                DateTime candidate = from.Date.AddHours(task.Hour).AddMinutes(task.Minute);
                return candidate > from ? candidate : candidate.AddDays(1);
            }
            case "weekly":
            {
                int target = (task.WeekDay ?? (int)from.DayOfWeek) % 7;
                int diff = (target - (int)from.DayOfWeek + 7) % 7;
                DateTime candidate = from.Date.AddHours(task.Hour).AddMinutes(task.Minute).AddDays(diff);
                return candidate > from ? candidate : candidate.AddDays(7);
            }
            case "monthly":
            {
                int day = Math.Clamp(task.DayOfMonth ?? from.Day, 1, 31);
                DateTime candidate = BuildMonthly(from.Year, from.Month, day, task.Hour, task.Minute);
                if (candidate > from)
                    return candidate;
                DateTime nextMonth = from.AddMonths(1);
                return BuildMonthly(nextMonth.Year, nextMonth.Month, day, task.Hour, task.Minute);
            }
            case "yearly":
            {
                int month = Math.Clamp(task.Month ?? from.Month, 1, 12);
                int day = Math.Clamp(task.DayOfMonth ?? from.Day, 1, 31);
                DateTime candidate = BuildMonthly(from.Year, month, day, task.Hour, task.Minute);
                if (candidate > from)
                    return candidate;
                return BuildMonthly(from.Year + 1, month, day, task.Hour, task.Minute);
            }
            case "once":
                return task.ExactTime ?? DateTime.MaxValue;
            default:
                return DateTime.MaxValue;
        }
    }

    static DateTime BuildMonthly(int year, int month, int day, int hour, int minute)
    {
        int lastDay = DateTime.DaysInMonth(year, month);
        return new DateTime(year, month, Math.Min(day, lastDay), hour, minute, 0);
    }

    static string DescribeTask(ScheduledTask task)
    {
        string timeStr = $"{task.Hour:00}:{task.Minute:00}";
        return task.Type switch
        {
            "daily" => $"每天 {timeStr}",
            "weekly" => $"每周{((task.WeekDay ?? 0) is >= 0 and <= 6 ? "日一二三四五六"[task.WeekDay!.Value] : '?')} {timeStr}",
            "monthly" => $"每月{task.DayOfMonth}日 {timeStr}",
            "yearly" => $"每年{task.Month}月{task.DayOfMonth}日 {timeStr}",
            "once" => $"一次性 {task.ExactTime:yyyy-MM-dd HH:mm:ss}",
            _ => task.Type
        };
    }
}
